var test_url = {% url 'result-list' %};
