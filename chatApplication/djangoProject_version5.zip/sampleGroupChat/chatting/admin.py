from django.contrib import admin
from chatting.models import Chat, PermenantChat
# Register your models here.

admin.site.register(Chat)
admin.site.register(PermenantChat)
